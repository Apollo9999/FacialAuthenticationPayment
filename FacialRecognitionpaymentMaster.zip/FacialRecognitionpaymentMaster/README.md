# Facial-Authentication-Payment 

Facial recognition payment is a digital payment solution that utilizes facial recognition to authenticate the digital customers. It will be seamlessly integrated with country's leading digital wallet solutions.The proposed Universal platform consists ofusing Face Recognition for P2P transfer ,Shopping  at yourfavourite Restaurants or  Coffee Shops or Shopping Mall or Salon. Our project  platform unites all payment mode like Wallets Paytm , Amazon Pay , UPI payments  PhonePe, GooglePay , NFC  Visa PayWave, Mastercard Contactless  or even Banks

Advantages of the solution
Face ID stage for authentication of person.
Followed by a 2D to 3D contour mapping for phones without dot projectors to reduce the attacks by photos.
Liveness detection to remove any possibility of the subject being an image by doing a physical activity.



SOLUTION

Universal platform using Face Recognition for P2P transfer ,Shopping  at your favorite Coffee Shops or Shopping Mall or Salon. This platform unites all payment mode like Wallets (Paytm , Amazon Pay) , UPI(PhonePe,GooglePay) , NFC(Visa PayWave, Mastercard Contactless) or even Banks.
